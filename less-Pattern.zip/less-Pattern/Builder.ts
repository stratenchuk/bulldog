
class Product {
    private parts: string[] = [];

    public add(part: string): void {
        this.parts.push(part);
    }

    public showParts(): void {
        console.log(`Product parts: ${this.parts.join(', ')}`);
    }
}

interface Builder {
    buildPartA(): void;
    buildPartB(): void;
    getResult(): Product;
}

class ConcreteBuilder implements Builder {
    private product: Product = new Product();

    public buildPartA(): void {
        this.product.add('Part A');
    }

    public buildPartB(): void {
        this.product.add('Part B');
    }

    public getResult(): Product {
        return this.product;
    }
}

// Usage
const builder = new ConcreteBuilder();
builder.buildPartA();
builder.buildPartB();
const product = builder.getResult();
product.showParts(); // Product parts: Part A, Part B
