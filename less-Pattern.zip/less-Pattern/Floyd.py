def floyd_warshall(graph):
    # Количество вершин в графе
    num_vertices = len(graph)

    # Инициализация матрицы расстояний
    dist = [[float('inf')] * num_vertices for _ in range(num_vertices)]

    # Заполнение матрицы расстояний
    for i in range(num_vertices):
        for j in range(num_vertices):
            if i == j:
                dist[i][j] = 0
            elif graph[i][j] != 0:
                dist[i][j] = graph[i][j]

    # Основной цикл алгоритма Флойда-Уоршелла
    for k in range(num_vertices):
        for i in range(num_vertices):
            for j in range(num_vertices):
                if dist[i][j] > dist[i][k] + dist[k][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]

    return dist

# Пример использования
graph = [
    [0, 3, 0, 0, 0, 0],
    [0, 0, 1, 0, 0, 0],
    [0, 0, 0, 7, 0, 2],
    [0, 0, 0, 0, 2, 0],
    [0, 0, 0, 0, 0, 3],
    [0, 0, 0, 0, 0, 0]
]

shortest_paths = floyd_warshall(graph)
for row in shortest_paths:
    print(row)
