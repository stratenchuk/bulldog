
interface Subject {
    request(): void;
}

class RealSubject implements Subject {
    public request(): void {
        console.log('RealSubject: Handling request.');
    }
}

class Proxy implements Subject {
    private realSubject: RealSubject;

    constructor(realSubject: RealSubject) {
        this.realSubject = realSubject;
    }

    public request(): void {
        console.log('Proxy: Logging before real subject request.');
        this.realSubject.request();
        console.log('Proxy: Logging after real subject request.');
    }
}

// Usage
const realSubject = new RealSubject();
const proxy = new Proxy(realSubject);
proxy.request();
// Output:
// Proxy: Logging before real subject request.
// RealSubject: Handling request.
// Proxy: Logging after real subject request.
