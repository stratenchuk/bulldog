
interface Subject {
    request(): void;
}

class RealSubject implements Subject {
    public request(): void {
        console.log('RealSubject: Handling request.');
    }
}

class Proxy implements Subject {
    private realSubject: RealSubject;

    constructor() {
        this.realSubject = new RealSubject();
    }

    public request(): void {
        console.log('Proxy: Logging before real subject request.');
        this.realSubject.request();
        console.log('Proxy: Logging after real subject request.');
    }
}

// Usage
const proxy = new Proxy();
proxy.request();
