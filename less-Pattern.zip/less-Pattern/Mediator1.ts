
interface Mediator {
    notify(sender: object, event: string): void;
}

class ConcreteMediator implements Mediator {
    private component1: Component1;
    private component2: Component2;

    constructor(c1: Component1, c2: Component2) {
        this.component1 = c1;
        this.component1.setMediator(this);
        this.component2 = c2;
        this.component2.setMediator(this);
    }

    public notify(sender: object, event: string): void {
        if (event === 'A') {
            console.log('Mediator reacts on A and triggers the following operations:');
            this.component2.doC();
        } else if (event === 'B') {
            console.log('Mediator reacts on B and triggers the following operations:');
            this.component1.doA();
        }
    }
}

class Component1 {
    private mediator: Mediator;

    public setMediator(mediator: Mediator): void {
        this.mediator = mediator;
    }

    public doA(): void {
        console.log('Component1 does A.');
        this.mediator.notify(this, 'A');
    }
}

class Component2 {
    private mediator: Mediator;

    public setMediator(mediator: Mediator): void {
        this.mediator = mediator;
    }

    public doC(): void {
        console.log('Component2 does C.');
    }
}

// Usage
const c1 = new Component1();
const c2 = new Component2();
const mediator = new ConcreteMediator(c1, c2);
c1.doA();
